<template>
    <div class="style">
        <center><h1>
            𝟒𝟎𝟒 ! 𝐏𝐚𝐠𝐞 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝</h1>
            <br/>
            <h2>𝐢𝐭 𝐬𝐞𝐞𝐦𝐬 𝐲𝐨𝐮'𝐫𝐞 𝐢𝐧 𝐭𝐡𝐞 𝐰𝐫𝐨𝐧𝐠 𝐩𝐚𝐠𝐞</h2>
        </center>
    </div>
</template>
<style>
.style{
    margin-top:2%;
}
</style>